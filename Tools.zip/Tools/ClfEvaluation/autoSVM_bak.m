function [predict_label, accuracy] = autoSVM_bak(train_labels, train_features,...
                                                            test_labels, test_features)
%autoSVM train the SVM model automatically
%   train_labels: a (train_num) x (feature_num) matrix 
%   train_features: a (train_num) x 1 vector 

[c,g] = parCVGS(train_labels,train_features);
cmd = ['-q -c ', num2str(c), ' -g ', num2str(g)];
model = libsvmtrain(train_labels,train_features,cmd);
[predict_label, accuracy, dec_values] = libsvmpredict(test_labels,test_features,model);
accuracy = accuracy(1);
end

