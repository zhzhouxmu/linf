function [acc, pred_label] = AutoClf(train_gnd, train_fea,test_gnd,test_fea)
%AutoClf : Automatic training classifiers and calculation accuracy
%   train_gnd: train labels, #samples-by-1 matrix
%   train_fea: train features, #samples-by-#features maxtrix
%   test_gnd:  test labels, #samples-by-1 matrix
%   test_fea:  test features, #samples-by-#features matrix
%   acc:
%       acc.knn: k-NN classification accuracy
%       acc.svm: SVM classification accuracy
%   -----------------------------------------------------------------------
%   Training Methods:
%       k-NN: grid search for k,from 1 to 10
%       SVM:  grid search for c and gamma, from 2^-5 to 2^5

%% k-NN 
kloss = zeros(10,1);
for k = 1:10
    knnMdl = fitcknn(train_fea,train_gnd,"NumNeighbors",k);
    knnCVMdl = crossval(knnMdl,'kfold',3);
    kloss(k) = kfoldLoss(knnCVMdl);
end
[~,bestK] = min(kloss);
bestMdl = fitcknn(train_fea,train_gnd,"NumNeighbors",bestK);
pred_gnd = predict(bestMdl,test_fea);
cm = confusionmat(test_gnd,pred_gnd);
acc.knn = sum(diag(cm))/sum(sum(cm));
pred_label.knn = pred_gnd;

%% SVM
[pred_gnd, accuracy] = autoSVM_bak(train_gnd, train_fea,test_gnd,test_fea);
acc.svm = accuracy;
pred_label.svm = pred_gnd;

%{
% rng default
t = templateSVM('KernelFunction','rbf');
[SVMMdl,HyperparameterOptimizationResults] = fitcecoc(train_fea,train_gnd, ...
    'OptimizeHyperparameters','auto',...
    "HyperparameterOptimizationOptions",struct('Optimizer','gridsearch'),...
    "HyperparameterOptimizationOptions",struct('NumGridDivisions',5),...
    "HyperparameterOptimizationOptions",struct('Kfold',3),...
    "Options",statset('UseParallel',true)...
    )
pred_gnd = predict(SVMMdl,test_fea);
cm = confusionmat(test_gnd,pred_gnd);
acc.svm = sum(diag(cm))/sum(sum(cm));
pred_label.svm = pred_gnd;
% ����MATLAB ��������
%}
end

