function [data, setParas] = getDataset(set,opt)
%��ȡ����ѧϰ���ݼ�
%   dataset    ѡ�����ݼ�
%   opt        ���ݼ�ѡ��
%   stateCode  ����ִ��״̬

switch set
    case 'mnist'
        [data,setParas] = getMNIST(opt);
    case 'coil'
        [data, setParas] = getCOIL(opt);
    case 'mnist_n'
        [data, setParas] = getMNISTnoise(opt);
    case 'coil_n'
        [data, setParas] = getCOILnoise(opt);
    otherwise
        warning("Unexpected !")
end
%{
if strcmp(set,'mnist')
    setParas = getMNIST(opt);
else
    if strcmp(set,'coil')
    setParas = getCOIL(opt);
    elseif strcmp(set,'testSize')
        setParas = getTS(opt);
    else
        error("No such dataset exist!")
   end
end
%}
end

function [setParas] = getTS(opt)
% Generate synthetic data
    numOfTrain = opt.num_train;
    numOfTest = opt.num_test;
    width = opt.test_width;
    height = opt.test_height;
    
    train_tensor = tensor(rand(width,height,numOfTrain));
    test_tensor = tensor(rand(width,height,numOfTest));
    
    save train_tensor train_tensor
    save test_tensor test_tensor
    
    setParas = 0;
end
