function [data, setParas] = getMNISTnoise(opt)
%��ȡMNIST���ݼ�
%   ÿ��ͼƬԪ��Ϊ˫���ȵ� 0~1
%   ͨ���������������ʾ��ͼƬ��

 
numOfTrain = opt.num_train;
numOfTest = opt.num_test;


load('./Datasets/mnistHelp/trainImages');
load('./Datasets/mnistHelp/trainLabels') ;
load('./Datasets/mnistHelp/testImages');
load('./Datasets/mnistHelp/testLabels');
trainLabels = trainLabels(1:numOfTrain);
testLabels = testLabels(1:numOfTest);
trainImages = trainImages(:,1:numOfTrain);
testImages = testImages(:,1:numOfTest);



trainImagesI = reshape(trainImages,[28 28 numOfTrain]);
testImagesI = reshape(testImages,[28 28 numOfTest]);
trainDownSample = trainImagesI(1:2:end,1:2:end,:);
trainDownSample(:,:,1:10) = imnoise(trainDownSample(:,:,1:10),'salt & pepper',0.8);
testDownSample = testImagesI(1:2:end,1:2:end,:);
% testDownSample = imnoise(testDownSample,'gaussian');
trainImages = reshape(trainDownSample,[196,numOfTrain]);
testImages = reshape(testDownSample,[196,numOfTest]);




data.trainImages = trainImages;
data.trainLabels = trainLabels;
data.testImages = testImages;
data.testLabels = testLabels;
save('./CacheData/trainImages','trainImages');
save('./CacheData/testImages','testImages');
save('./CacheData/trainLabels','trainLabels');
save('./CacheData/testLabels','testLabels');

setParas.width = 14;
setParas.height = 14;
setParas.trainNum = numOfTrain;
setParas.testNum = numOfTest;
end