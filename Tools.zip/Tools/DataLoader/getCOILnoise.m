function [data, setParas] = getCOILnoise(opt)
%
    %
numOfTrain = opt.num_train;
numOfTest = opt.num_test;

load('./Datasets/COIL-20/COIL20.mat')
r = randperm(1440);

image = X(r,:);
label = Y(r,:);
trainImages = image(1:numOfTrain,:)';
trainImages(1:10,:) = imnoise(trainImages(1:10,:),'salt & pepper',0.8);
trainLabels = label(1:numOfTrain);
testImages = image(end-numOfTest+1:end,:)';
% testImages = imnoise(testImages,'gaussian');
testLabels = label(end-numOfTest+1:end);

data.trainImages = trainImages;
data.trainLabels = trainLabels;
data.testImages = testImages;
data.testLabels = testLabels;
save('./CacheData/trainImages','trainImages');
save('./CacheData/testImages','testImages'); 
save('./CacheData/trainLabels','trainLabels');
save('./CacheData/testLabels','testLabels');

setParas.width = 32;
setParas.height = 32;
setParas.trainNum = numOfTrain;
setParas.testNum = numOfTest;
end