clear all;
% load('C:\Users\PakuZhou\Documents\MATLAB\Code\fe_new\Results\coil-200-1200-30_29-Apr-2019h02m19s29\coil-200-1200-30_29-Apr-2019h02m19s29.mat')
% [cidx3,cmeans3] = kmeans(trainImages',10,'Display','iter');


% [cidx3,cmeans3,sumd3] = kmeans(testImages',10,'replicates',10,'display','final');
% [silh3,h] = silhouette(testImages',cidx3,'sqeuclidean');


load fisheriris
[cidx2,cmeans2] = kmeans(meas,3,'dist','sqeuclidean','replicates',10,'display','final');
[silh2,h] = silhouette(meas,cidx2,'sqeuclidean');
t1 = ones(50,1);
species = [t1;t1+1;t1+2];
diff = cidx2 - species;
addpath('./Tools/ClstEvaluation/')
clst_acc = clstAcc(cidx2,species);
clst_nmi = clstNMI(cidx2,species);

fprintf("acc %f, nmi %f",clst_acc,clst_nmi);

%% ================================================================
%{
eucD = pdist(trainImages','euclidean');
clustTreeEuc = linkage(eucD,'average');
cophenet(clustTreeEuc,eucD)
[h,nodes] = dendrogram(clustTreeEuc,0);
h_gca = gca;
h_gca.TickDir = 'out';
h_gca.TickLength = [.002 0];
h_gca.XTickLabel = [];
%}

