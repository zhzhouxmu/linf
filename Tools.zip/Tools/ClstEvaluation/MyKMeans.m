function [clst_acc,clst_nmi,cidx] = MyKMeans(features,labels,clstNum)
%MYKMEANS 
% features: a sample_num-by-feature_num matrix
% labels:   a sample_num-by-1 vector

[cidx] = kmeans(features,clstNum,'dist','sqeuclidean','replicates',10,'display','final');
clst_acc = clstAcc(cidx,labels);
clst_nmi = clstNMI(cidx',labels');
% clst_nmi = 0;
end

